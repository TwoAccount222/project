from .forms import SearchForm # Импортируем форму поиска
from shop.cart import Cart

# Контекстный процессор для корзины.
# Добавляет объект 'cart' в контекст всех шаблонов.
def cart(request):
    # Возвращает словарь, где ключ 'cart' - это экземпляр класса Cart.
    # Таким образом, в любом шаблоне можно будет обратиться к {{ cart }}.
    return {'cart': Cart(request)}

# Контекстный процессор для формы поиска.
# Добавляет объект 'search_form' в контекст всех шаблонов.
def search_form_context(request):
    # Возвращает словарь с экземпляром SearchForm.
    # Это позволяет отобразить форму поиска, например, в шапке сайта (base.html).
    # Сама обработка поиска происходит в представлении product_list.
    return {'search_form': SearchForm()}